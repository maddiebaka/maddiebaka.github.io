// Project: StoreKitExample
// Created by madeline
//
// 2023

import SwiftUI
import StoreKit

struct ContentView: View {
    let productIDs: [String] = ["Product1", "Product2"]
    let subscriptionGroupID = "7E08E2CD"

    var body: some View {
        TabView {
            StoreView(ids: productIDs)
            .tabItem {
                Image(systemName: "storefront")
                Text("StoreView")
            }
            SubscriptionStoreView(groupID: subscriptionGroupID)
            .tabItem {
                Image(systemName: "dollarsign.arrow.circlepath")
                Text("SubscriptionStoreView")
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
