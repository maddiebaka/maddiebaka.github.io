// Project: StoreKitExample
// Created by madeline
//
// 2023

import SwiftUI

@main
struct StoreKitExampleApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
